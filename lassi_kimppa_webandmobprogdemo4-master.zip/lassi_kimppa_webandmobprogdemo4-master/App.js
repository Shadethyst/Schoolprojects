import { StatusBar } from 'expo-status-bar';
import { StyleSheet} from 'react-native';
import * as React from 'react';
import { Text, View, Button, ActivityIndicator, TextInput, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {NoteList} from './components/noteList.js';
import {CreationScreen} from './components/creationScreen.js'


const Stack = createStackNavigator();

export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Notes">
                <Stack.Screen name="Notes" component={NoteList} />
                <Stack.Screen name="NoteCreation" component={CreationScreen} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}




const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
