﻿import { StatusBar } from 'expo-status-bar';
import { StyleSheet } from 'react-native';
import * as React from 'react';
import { Text, View, Button, ActivityIndicator, TextInput, ScrollView, Alert} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useState } from 'react';

export class CreationScreen extends React.Component {

    state = {
        text: ""
    }
    render() {
        return (
            <View>
                <TextBuffer/>
                <NoteButton
                    navigation={this.props.navigation}
                    note={this.state.text}
                />
            </View>
        );

    }
}
const TextBuffer = () => {
    const [text, setText] = useState('');
    return (
        <View style={{ padding: 10 }}>
            <TextInput
                style={{ height: 40 }}
                placeholder="Type note here!"
                onChangeText={newText => setText(newText)}
                defaultValue={text}
            />
        </View>
    );
}
const NoteButton = (props) => {
    return (
        <Button title="add note" onPress={() => props.navigation.navigate('Notes', { notetext: props.note })} />
    );
}