import { StatusBar } from 'expo-status-bar';
import { StyleSheet} from 'react-native';
import * as React from 'react';
import { Text, View, Button, ActivityIndicator, TextInput, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';



export class NoteList extends React.Component {
    handleText = (text) => { this.setState({ newtext: text }) }
    constructor(props) {
        super(props);
        this.state = {
            newtext: "",
            notes: [
                {
                    id: 7,
                    text: "test1"
                },
                {
                    id: 1,
                    text: "test2"
                },
                {
                    id: 2,
                    text: "test3"
                },
                {
                    id: 3,
                    text: "test4"
                },
                {
                    id: 4,
                    text: "test5"
                },
                {
                    id: 5,
                    text: "test6"
                },
                {
                    id: 6,
                    text: "test7"
                }
            ]
        }
    }


    render() {
        return (
            <View style={[styles.container, {
                flexDirection: "column"
            }]}>
                <ScrollView style={styles.notestyle}>
                {this.state.notes.map(note => <Note key={note.id} note={note.text} />)}

               

                </ScrollView>
                <TextInput
                    style={{ minHeight: 50,}}
                    placeholder="Type note here!"
                    onChangeText={this.handleText}
                />
                    <CreationButton
                        notes={this.state.notes}
                        navigation={this.props.navigation} />
                <Button
                    style={styles.buttonstyle}
                        title="Add Note"
                        onPress={() => {
                            
                            this.setState(prevState => ({
                                notes: [...prevState.notes, { id: Math.random() * 100, text: this.state.newtext }]
                            }))
                        }} />
            </View>

        );

    }

}



const CreationButton = (props) => {
    return (
        <Button style={styles.buttonstyle} title="Create Note" onPress={() => props.navigation.navigate('NoteCreation')} />
    );
}

const Note = (props) => {
    return (
        <View>
            <Text>{props.note}</Text>
        </View>
    );

}
const styles = StyleSheet.create({
    container: {
        flex:1,
        backgroundColor: 'darkgreen',
        padding: 10,
        height: 100,
        justifyContent: 'center'
    },
    notestyle: {
        flex: 2,
        backgroundColor: "red"
    },
    buttonstyle: {
        flex: 3,
        padding: 40
    }
});
