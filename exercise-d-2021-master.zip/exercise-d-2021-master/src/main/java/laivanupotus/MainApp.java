package laivanupotus;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application{

	Scene scene1, scene2;
	
	@Override
	public void start(Stage stage) throws Exception {
		
		
		var resourceRoot = getClass();
		var form = "StartMenu.fxml";
		var loader = new FXMLLoader(resourceRoot.getResource(form));
		Parent root = loader.load();
		scene1 = new Scene(root);
		stage.setTitle("LaivanUpotus");
		stage.setScene(scene1);
		stage.show();
		ShipBoardData.addStage(stage, 3);
		ShipBoardData.setShipBoardController(loader.getController());
	}

}
