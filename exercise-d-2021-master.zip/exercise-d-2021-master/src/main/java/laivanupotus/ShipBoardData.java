package laivanupotus;

import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

//container class for game data
public class ShipBoardData {
	
	private static String pl1Name;
	private static String pl2Name;
	private static int boardSize;
	private static int destroyerAmount;
	private static int submarineAmount;
	private static int cruiserAmount;
	private static int battleshipAmount;
	private static int carrierAmount;
	private static GridPane player1Pane = new GridPane();
	private static GridPane player2Pane = new GridPane();
	private static String winnerName;
	
	private static int[][] board1;
	private static int[][] board2;
	
	private static int plHp;
	
	private static int direction = 1;
	private static int length;
	private static Image image;
	private static Image carrierImagevert;
	private static Image waterImage;
	private static Image destroyerHead;
	private static Image destroyerEnd;
	private static Image cruiserHead;
	private static Image cruiserMiddle;
	private static Image cruiserEnd;
	
	private static Stage[] stages = new Stage[4];
	private static SettingBoardController settingController;
	private static GameplayController gameController;
	private static ShipBoardController shipBoardController;
	private static WinController winController;
	
	
	
	public static String getPl1Name() {
		return pl1Name;
	}
	public static void setPl1Name(String pl1Name) {
		ShipBoardData.pl1Name = pl1Name;
	}
	public static String getPl2Name() {
		return pl2Name;
	}
	public static void setPl2Name(String pl2Name) {
		ShipBoardData.pl2Name = pl2Name;
	}
	public static int[][] getBoard1() {
		return board1;
	}
	public static void setBoard1(int[][] board1) {
		ShipBoardData.board1 = board1;
	}
	public static int[][] getBoard2() {
		return board2;
	}
	public static void setBoard2(int[][] board2) {
		ShipBoardData.board2 = board2;
	}
	public static int getPlHp() {
		return plHp;
	}
	public static void setPlHp(int plHp) {
		ShipBoardData.plHp = plHp;
	}
	public static int getBoardSize() {
		return boardSize;
	}
	public static void setBoardSize(int boardSize) {
		ShipBoardData.boardSize = boardSize;
	}
	public static int getDirection() {
		return direction;
	}
	public static void setDirection(int direction) {
		ShipBoardData.direction = direction;
	}
	public static int getLength() {
		return length;
	}
	public static void setLength(int length) {
		ShipBoardData.length = length;
	}
	public static Image getImage() {
		return image;
	}
	public static void setImage(Image image) {
		ShipBoardData.image = image;
	}
	public static Image getCarrierImagevert() {
		return carrierImagevert;
	}
	public static void setCarrierImagevert(Image carrierImagevert) {
		ShipBoardData.carrierImagevert = carrierImagevert;
	}
	public static int getDestroyerAmount() {
		return destroyerAmount;
	}
	public static void setDestroyerAmount(int destroyerAmount) {
		ShipBoardData.destroyerAmount = destroyerAmount;
	}
	public static int getSubmarineAmount() {
		return submarineAmount;
	}
	public static void setSubmarineAmount(int submarineAmount) {
		ShipBoardData.submarineAmount = submarineAmount;
	}
	public static int getCruiserAmount() {
		return cruiserAmount;
	}
	public static void setCruiserAmount(int cruiserAmount) {
		ShipBoardData.cruiserAmount = cruiserAmount;
	}
	public static int getBattleshipAmount() {
		return battleshipAmount;
	}
	public static void setBattleshipAmount(int battleshipAmount) {
		ShipBoardData.battleshipAmount = battleshipAmount;
	}
	public static int getCarrierAmount() {
		return carrierAmount;
	}
	public static void setCarrierAmount(int carrierAmount) {
		ShipBoardData.carrierAmount = carrierAmount;
	}
	public static Image getDestroyerHead() {
		return destroyerHead;
	}
	public static void setDestroyerHead(Image destroyerHead) {
		ShipBoardData.destroyerHead = destroyerHead;
	}
	public static Image getDestroyerEnd() {
		return destroyerEnd;
	}
	public static void setDestroyerEnd(Image destroyerEnd) {
		ShipBoardData.destroyerEnd = destroyerEnd;
	}
	public static Image getCruiserHead() {
		return cruiserHead;
	}
	public static void setCruiserHead(Image cruiserHead) {
		ShipBoardData.cruiserHead = cruiserHead;
	}
	public static Image getCruiserMiddle() {
		return cruiserMiddle;
	}
	public static void setCruiserMiddle(Image cruiserMiddle) {
		ShipBoardData.cruiserMiddle = cruiserMiddle;
	}
	public static Image getCruiserEnd() {
		return cruiserEnd;
	}
	public static void setCruiserEnd(Image cruiserEnd) {
		ShipBoardData.cruiserEnd = cruiserEnd;
	}
	public static Image getWaterImage() {
		return waterImage;
	}
	public static void setWaterImage(Image waterImage) {
		ShipBoardData.waterImage = waterImage;
	}
	public static GridPane getPlayer1Pane() {
		return player1Pane;
	}
	public static void setPlayer1Pane(GridPane player1Pane) {
		ShipBoardData.player1Pane = player1Pane;
	}
	public static GridPane getPlayer2Pane() {
		return player2Pane;
	}
	public static void setPlayer2Pane(GridPane player2Pane) {
		ShipBoardData.player2Pane = player2Pane;
	}
	public static Stage[] getStages() {
		return stages;
	}
	public static void setStages(Stage[] stages) {
		ShipBoardData.stages = stages;
	}
	public static void addStage(Stage stage, int index) {
		ShipBoardData.stages[index] = stage;
	}
	public static SettingBoardController getSettingController() {
		return settingController;
	}
	public static void setSettingController(SettingBoardController settingController) {
		ShipBoardData.settingController = settingController;
	}
	public static GameplayController getGameController() {
		return gameController;
	}
	public static void setGameController(GameplayController gameController) {
		ShipBoardData.gameController = gameController;
	}
	public static ShipBoardController getShipBoardController() {
		return shipBoardController;
	}
	public static void setShipBoardController(ShipBoardController shipBoardController) {
		ShipBoardData.shipBoardController = shipBoardController;
	}
	public static WinController getWinController() {
		return winController;
	}
	public static void setWinController(WinController winController) {
		ShipBoardData.winController = winController;
	}
	public static String getWinnerName() {
		return winnerName;
	}
	public static void setWinnerName(String winnerName) {
		ShipBoardData.winnerName = winnerName;
	}
	
	
	
}
