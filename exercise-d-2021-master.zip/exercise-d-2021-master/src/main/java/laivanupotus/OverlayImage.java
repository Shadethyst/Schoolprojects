package laivanupotus;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

//Wrapper class for overlayimages to tell them apart from ship images
public class OverlayImage extends ImageView{
	public OverlayImage(Image img) {
		super(img);
	}
}
