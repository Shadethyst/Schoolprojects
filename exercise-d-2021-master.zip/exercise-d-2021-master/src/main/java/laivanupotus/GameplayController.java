package laivanupotus;

import java.io.IOException;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class GameplayController {
	public void initialize() throws IOException {
		Platform.runLater(()->{
			playerTurnLabel.setText(ShipBoardData.getPl1Name() + "'s turn");
		});
	}
	/**
	 * sets player to other player, shows gameboard for the changed player
	 */
	@FXML
	private void onPress() {
		if(currentPlayer == 1) {
			currentPlayer = 2;
		} else currentPlayer = 1;
		ShipBoardData.getSettingController().startTurn(currentPlayer);
		System.out.println("Starting new turn");
		ShipBoardData.getStages()[1].hide();
		ShipBoardData.getStages()[0].show();
	}
	/**
	 *  set the label to show the next player's name
	 */
	public void changeTurn(){
		Platform.runLater(()->{
			playerTurnLabel.setText((currentPlayer == 2 ? ShipBoardData.getPl1Name() : ShipBoardData.getPl2Name()) + "'s turn");
		});
	}

	public int getCurrentPlayer() {
		return currentPlayer;
	}
	public void setCurrentPlayer(int currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	private int currentPlayer;
	
	@FXML
	private Pane callPane;
	@FXML
	private Label playerTurnLabel;
	@FXML
	private Button continueButton;
}
