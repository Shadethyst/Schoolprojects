package laivanupotus;

import java.io.IOException;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.NumberBinding;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

//shipboardcontroller asks the user for game settings like names, the amount of ships and the size of the board
public class ShipBoardController {

 public void initialize() {
	 for(int i = 5;i<11;i++ ) {
	 boardSizeBox.getItems().add(i);
	};
	boardSizeBox.setValue(5);
	var boardP = new SimpleIntegerProperty(boardSizeBox.valueProperty().get());
	var boardS = boardP.multiply(boardP);
	shipsSize.setValue(0);
	var boundShipSize = shipsSize.multiply(1);
	var shipsFit = boardS.greaterThan(boundShipSize);
	boardFitLabel.textProperty().bind(Bindings.when(shipsFit).then("ships fit board").otherwise("Ships dont fit"));
	boardFitLabel.textFillProperty().bind(Bindings.when(shipsFit).then(Color.GREEN).otherwise(Color.RED));
	startButton.disableProperty().bind(Bindings.when(shipsFit).then(false).otherwise(true));
	boardSizeBox.valueProperty().addListener(ObservableObjectValue ->{
		boardP.set(boardSizeBox.getValue());
		});
	destroyerField.textProperty().addListener(ObservableObjectValue-> {
		refreshUI(1);
	});
	cruiserField.textProperty().addListener(ObservableObjectValue -> {
		refreshUI(2);

	});
	submarineField.textProperty().addListener(ObservableObjectValue -> {
		refreshUI(3);
	});
	battleshipField.textProperty().addListener(ObservableObjectValue -> {
		refreshUI(4);

	});
	carrierField.textProperty().addListener(ObservableObjectValue -> {
		refreshUI(5);
	});

}
 //reinitializes the settings screen when the next game starts
 public void reinit() {
	 Platform.runLater(() -> {
		 boardSizeBox.setValue(5);
	 	destroyerField.setText("0");
	 	cruiserField.setText("0");
	 	submarineField.setText("0");
	 	battleshipField.setText("0");
	 	carrierField.setText("0");
	 	player1NameField.setText("");
	 	player2NameField.setText("");
	 });
 }
	
	private SimpleIntegerProperty shipsSize = new SimpleIntegerProperty(0);
	@FXML
	private TextField player1NameField;
	@FXML
	private TextField player2NameField;
	@FXML
	private ChoiceBox<Integer> boardSizeBox;
	@FXML
	private TextField destroyerField;
	@FXML
	private TextField submarineField;
	@FXML
	private TextField cruiserField;
	@FXML
	private TextField battleshipField;
	@FXML
	private TextField carrierField;
	@FXML
	private Label boardFitLabel;
	@FXML 
	private Button startButton;
	
	private boolean alreadyStarted = false;
	
	//refreshes ui when ship amount is changed
	void refreshUI(int shipType) {
		int destroyerAmount = 100;
		int cruiserAmount  = 100;
		int submarineAmount = 100;
		int battleshipAmount = 100;
		int carrierAmount = 100;
		try {
			destroyerAmount = Integer.parseInt(destroyerField.getText());
			}catch(NumberFormatException e) {
			 
			}
		try {
			cruiserAmount = Integer.parseInt(cruiserField.getText());
			}catch(NumberFormatException e) {
				
			}
		try {
			submarineAmount = Integer.parseInt(submarineField.getText());
			}catch(NumberFormatException e) {
				
			}
		try {
			battleshipAmount = Integer.parseInt(battleshipField.getText());
			}catch(NumberFormatException e) {
				
			}
		try {
			carrierAmount = Integer.parseInt(carrierField.getText());
			}catch(NumberFormatException e) {
				
			}
		switch(shipType) {
		case 1:
			ShipBoardData.setDestroyerAmount(destroyerAmount);
			break;
		case 2:
			ShipBoardData.setCruiserAmount(cruiserAmount);
			break;
		case 3:
			ShipBoardData.setSubmarineAmount(submarineAmount);
			break;
		case 4:
			ShipBoardData.setBattleshipAmount(battleshipAmount);
			break;
		case 5:
			ShipBoardData.setCarrierAmount(carrierAmount);
			break;
		}
		
		shipsSize.setValue((((destroyerAmount*2)
				+(cruiserAmount*3)
				+(submarineAmount*3)
				+(battleshipAmount*4)
				+(carrierAmount*5))*2)
				
				);
		System.out.println("shipssize: " + shipsSize);
		
	}
	
	/**
	 * starts placement of ships on board,
	 * sets amounts of ships, names of players, maximum hp of players, size of board into data container
	 * @throws IOException
	 */
	@FXML
	void startGame(){
		var pl1Name = player1NameField.textProperty().get();
		var pl2Name = player2NameField.textProperty().get();
		var plHp = shipsSize.get() / 2;
		var boardSize = 0;
		boardSize = boardSizeBox.getValue();
		int[][] board = new int[boardSize][boardSize];
		int[][] board2 = new int[boardSize][boardSize];
		
		ShipBoardData.setDestroyerAmount(Integer.parseInt(destroyerField.getText()));
		ShipBoardData.setCruiserAmount(Integer.parseInt(cruiserField.getText()));
		ShipBoardData.setSubmarineAmount(Integer.parseInt(submarineField.getText()));
		ShipBoardData.setBattleshipAmount(Integer.parseInt(battleshipField.getText()));
		ShipBoardData.setCarrierAmount(Integer.parseInt(carrierField.getText()));
		
		ShipBoardData.setBoard1(board);
		ShipBoardData.setBoard2(board2);
		
		ShipBoardData.setPlHp(plHp);
		
		ShipBoardData.setPl1Name(pl1Name);
		ShipBoardData.setPl2Name(pl2Name);
		
		ShipBoardData.setBoardSize(boardSize);
		if(!alreadyStarted) {
			try {
		var resourceRoot = getClass();
		var form = "ShipSetMenu.fxml";
		var loader = new FXMLLoader(resourceRoot.getResource(form));
		Parent root = loader.load();
		var scene = new Scene(root);
		var stage = new Stage();
		stage.setTitle("LaivanUpotus");
		stage.setScene(scene);
		stage.setMaximized(true);
		ShipBoardData.getStages()[3].hide();
		stage.show();
		ShipBoardData.addStage(stage, 0);
		ShipBoardData.setSettingController(loader.getController());
		scene.addEventFilter(KeyEvent.KEY_TYPED, e ->{
			if(e.getCharacter().equals("r")) {
				switch(SettingBoardController.getDirection().get()) {
				case 1:
					SettingBoardController.setDirection(2);
					System.out.println("Direction changed to right");
					break;
				case 2:
					SettingBoardController.setDirection(3);
					System.out.println("Direction changed to down");
					break;
				case 3:
					SettingBoardController.setDirection(4);
					System.out.println("Direction changed to left");
					break;
				case 4:
					SettingBoardController.setDirection(1);
					System.out.println("Direction changed to up");
					break;
				}
			}
		});
		alreadyStarted = true;
		}catch(IOException e) {
			e.printStackTrace();
		}
		}else {
			ShipBoardData.getSettingController().reinit();
			ShipBoardData.getStages()[3].hide();
			ShipBoardData.getStages()[0].show();
		}


		
	}
}
