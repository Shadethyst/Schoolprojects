package laivanupotus;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.application.Platform;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DataFormat;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

//the main class for game logic
public class SettingBoardController {

	Ship[] ships1;
	Ship[] ships2;
	int runningShipId;
	
	//initialize the game board
	public void initialize() {
		Image carrierImage = new Image(getClass().getResource("CarrierH.png").toExternalForm());
		Image destroyerImage = new Image(getClass().getResource("DestroyerH.png").toExternalForm());
		Image cruiserImage = new Image(getClass().getResource("CruiserH.png").toExternalForm());
		Image submarineImage= new Image(getClass().getResource("SubmarineH.png").toExternalForm());
		Image battleshipImage = new Image(getClass().getResource("BattleshipH.png").toExternalForm());
		Image waterImage  = new Image(getClass().getResource("water200px.png").toExternalForm());
		Image directionArrow = new Image(getClass().getResource("Arrow.png").toExternalForm());
		
		paneWidth = 800;
		paneHeight = 800;
		
		playerHP = new int[2];
		playerHP[0] = ShipBoardData.getPlHp();
		playerHP[1] = ShipBoardData.getPlHp();
		
		directionImage.setImage(directionArrow);
		directionImage.setImage(directionArrow);
		directionImage.rotateProperty().bind(direction.multiply(90).subtract(90));
		
		
		pl1Name = ShipBoardData.getPl1Name();
		pl2Name = ShipBoardData.getPl2Name();
		playerNames = new String[2];
		playerNames[0]=pl1Name;
		playerNames[1]=pl2Name;
		Platform.runLater(() -> {
			playerLabel.setText("Player 1: "+pl1Name+" setting ships" );
		});

		boardSize = ShipBoardData.getBoardSize();
		board1 = ShipBoardData.getBoard1();
		board2 = ShipBoardData.getBoard2();
		
		boardsList = new ArrayList<int[][]>();
		boardsList.add(board1);
		boardsList.add(board2);
		
		//set imageviews so that they may start a drag and drop
		draggableShip(type1ShipView, 2, "destroyer");
		draggableShip(type2ShipView, 3, "cruiser");
		draggableShip(type3ShipView, 3, "submarine");
		draggableShip(type4ShipView, 4, "battleship");
		draggableShip(type5ShipView, 5, "carrier");
		
		
		//get amounts of ships to place from data container
		destroyerAmount.set(ShipBoardData.getDestroyerAmount());
		cruiserAmount.set(ShipBoardData.getCruiserAmount());
		submarineAmount.set(ShipBoardData.getSubmarineAmount());
		battleshipAmount.set(ShipBoardData.getBattleshipAmount());
		carrierAmount.set(ShipBoardData.getCarrierAmount());
		
		
		//bind amounts of ships left to place to labels to show to user
		destroyerAmoutLabel.textProperty().bind(destroyerAmount.asString());
		cruiserAmoutLabel.textProperty().bind(cruiserAmount.asString());
		submarineAmoutLabel.textProperty().bind(submarineAmount.asString());
		battleshipAmoutLabel.textProperty().bind(battleshipAmount.asString());
		carrierAmoutLabel.textProperty().bind(carrierAmount.asString());

		gridPanes = new GridPane[4];

		battleshipBoard1 = new GridPane();
		battleshipBoard2 = new GridPane();
		battleshipBoard3 = new GridPane();
		battleshipBoard4 = new GridPane();
		
		vboxL.getChildren().add(battleshipBoard1);
		
		gridPanes[0] = battleshipBoard1;
		gridPanes[1] = battleshipBoard2;
		gridPanes[2] = battleshipBoard3;
		gridPanes[3] = battleshipBoard4;
		
		ships1 = new Ship[getShipAmount()];
		ships2 = new Ship[getShipAmount()];
		runningShipId = 1;
		
		
		//set stackpanes on grid and set image of water as background
		for(int z = 0; z < 2;z++) {
			for(int i = 0;i<boardSize;i++) {
				for(int j = 0;j<boardSize;j++) {
					StackPane stack = new StackPane();
					StackPane stack1 = new StackPane();
					Background back = new Background(new BackgroundImage(waterImage,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,BackgroundSize.DEFAULT));
					stack.setMinSize(800/boardSize, 800/boardSize);
					stack.setPrefSize(800/boardSize, 800/boardSize);
					stack.setBackground(back);
					stack.setId(String.valueOf(j)+String.valueOf(i));
					stack1.setMinSize(800/boardSize, 800/boardSize);
					stack1.setPrefSize(800/boardSize, 800/boardSize);
					stack1.setBackground(back);
					stack1.setId(String.valueOf(j)+String.valueOf(i));
					addDropHandling(stack);
					gridPanes[z].add(stack, j, i);
					addShootHandling(stack1);
					gridPanes[z+2].add(stack1, j, i);
				}
			}
		}
		
		
		//set images to Imageviews from which to drag ships onto board
		type1ShipView.setImage(destroyerImage);
		type2ShipView.setImage(cruiserImage);
		type3ShipView.setImage(submarineImage);
		type4ShipView.setImage(battleshipImage);
		type5ShipView.setImage(carrierImage);
	}
	//return the amount of ships that was set initially
	public int getShipAmount() {
		return ShipBoardData.getDestroyerAmount() +
				ShipBoardData.getCruiserAmount() +
				ShipBoardData.getSubmarineAmount() +
				ShipBoardData.getBattleshipAmount() +
				ShipBoardData.getCarrierAmount();
	}
	/**
	 * reinitializes variables used for the UI and the game when a new game is started
	 */
	public void reinit() {
		Image carrierImage = new Image(getClass().getResource("CarrierH.png").toExternalForm());
		Image destroyerImage = new Image(getClass().getResource("DestroyerH.png").toExternalForm());
		Image cruiserImage = new Image(getClass().getResource("CruiserH.png").toExternalForm());
		Image submarineImage= new Image(getClass().getResource("SubmarineH.png").toExternalForm());
		Image battleshipImage = new Image(getClass().getResource("BattleshipH.png").toExternalForm());
		Image waterImage  = new Image(getClass().getResource("water200px.png").toExternalForm());
		Image directionArrow = new Image(getClass().getResource("Arrow.png").toExternalForm());
		
		paneWidth = 800;
		paneHeight = 800;
		
		playerHP = new int[2];
		playerHP[0] = ShipBoardData.getPlHp();
		playerHP[1] = ShipBoardData.getPlHp();
		
		directionImage.setImage(directionArrow);
		directionImage.setImage(directionArrow);
		directionImage.rotateProperty().bind(direction.multiply(90).subtract(90));
		
		
		pl1Name = ShipBoardData.getPl1Name();
		pl2Name = ShipBoardData.getPl2Name();
		playerNames = new String[2];
		playerNames[0]=pl1Name;
		playerNames[1]=pl2Name;
		Platform.runLater(() -> {
			playerLabel.setText("Player 1: "+pl1Name+" setting ships" );
		});

		boardSize = ShipBoardData.getBoardSize();
		board1 = ShipBoardData.getBoard1();
		board2 = ShipBoardData.getBoard2();
		
		boardsList = new ArrayList<int[][]>();
		boardsList.add(board1);
		boardsList.add(board2);
		
		//set imageviews so that they may start a drag and drop
		draggableShip(type1ShipView, 2, "destroyer");
		draggableShip(type2ShipView, 3, "cruiser");
		draggableShip(type3ShipView, 3, "submarine");
		draggableShip(type4ShipView, 4, "battleship");
		draggableShip(type5ShipView, 5, "carrier");
		
		
		//get amounts of ships to place from data container
		destroyerAmount.set(ShipBoardData.getDestroyerAmount());
		cruiserAmount.set(ShipBoardData.getCruiserAmount());
		submarineAmount.set(ShipBoardData.getSubmarineAmount());
		battleshipAmount.set(ShipBoardData.getBattleshipAmount());
		carrierAmount.set(ShipBoardData.getCarrierAmount());
		
		
		//bind amounts of ships left to place to labels to show to user
		destroyerAmoutLabel.textProperty().bind(destroyerAmount.asString());
		cruiserAmoutLabel.textProperty().bind(cruiserAmount.asString());
		submarineAmoutLabel.textProperty().bind(submarineAmount.asString());
		battleshipAmoutLabel.textProperty().bind(battleshipAmount.asString());
		carrierAmoutLabel.textProperty().bind(carrierAmount.asString());

		gridPanes = new GridPane[4];

		battleshipBoard1 = new GridPane();
		battleshipBoard2 = new GridPane();
		battleshipBoard3 = new GridPane();
		battleshipBoard4 = new GridPane();
		
		vboxL.getChildren().set(1, battleshipBoard1);
		
		gridPanes[0] = battleshipBoard1;
		gridPanes[1] = battleshipBoard2;
		gridPanes[2] = battleshipBoard3;
		gridPanes[3] = battleshipBoard4;
		
		ships1 = new Ship[getShipAmount()];
		ships2 = new Ship[getShipAmount()];
		runningShipId = 1;
		
		Platform.runLater(()-> {
			labelL.setText("Place your ships here");
		});
		
		//set stackpanes on grid and set image of water as background
		for(int z = 0; z < 2;z++) {
			for(int i = 0;i<boardSize;i++) {
				for(int j = 0;j<boardSize;j++) {
					StackPane stack = new StackPane();
					StackPane stack1 = new StackPane();
					Background back = new Background(new BackgroundImage(waterImage,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,BackgroundSize.DEFAULT));
					stack.setMinSize(800/boardSize, 800/boardSize);
					stack.setPrefSize(800/boardSize, 800/boardSize);
					stack.setBackground(back);
					stack.setId(String.valueOf(j)+String.valueOf(i));
					stack1.setMinSize(800/boardSize, 800/boardSize);
					stack1.setPrefSize(800/boardSize, 800/boardSize);
					stack1.setBackground(back);
					stack1.setId(String.valueOf(j)+String.valueOf(i));
					addDropHandling(stack);
					gridPanes[z].add(stack, j, i);
					addShootHandling(stack1);
					gridPanes[z+2].add(stack1, j, i);
				}
			}
		}
		
		
		//set images to Imageviews from which to drag ships onto board
		type1ShipView.setImage(destroyerImage);
		type2ShipView.setImage(cruiserImage);
		type3ShipView.setImage(submarineImage);
		type4ShipView.setImage(battleshipImage);
		type5ShipView.setImage(carrierImage);
		
		
		boardPane.setLeft(directionImage);
		vboxR.getChildren().set(1, shipBox);
		resetButton.setOnAction(ActionEvent ->{resetPlacement();});
		bottomBox.getChildren().add(startButton);
		Platform.runLater(()->{
			labelR.setText("Ships To Place");
			resetButton.setText("Reset Placement");
			startButton.setText("Set Ships");
			shipPlacementLabel.setText("");
		});
	}
	
	/**
	 * add handling for starting drag and drop to ship options
	 * @param ship which imageview to use
	 * @param length how long ship is, used for checking how many panes to fill with images
	 * @param type used to check which ship you are dragging
	 */
	private void draggableShip(ImageView ship, int length, String type) {
		ship.setOnDragDetected(MouseEvent->{
			Dragboard db = ship.startDragAndDrop(TransferMode.COPY);
			ClipboardContent content = new ClipboardContent();
	        content.put(shipFormat, "  ");
	        db.setContent(content);
			System.out.println("dragging");
			ImageView im = new ImageView(ship.getImage());
			im.setFitHeight(paneHeight/ShipBoardData.getBoardSize());
			im.setFitWidth(paneWidth/ShipBoardData.getBoardSize());
			draggedShip = im;
			shipLength = length;
			shipType = type;
			
			
			
		});
	}

	/**
	 * check if there are any ships left in given category
	 * @param type ship type
	 */
	private boolean shipsLeft(String type) {
		switch(type) {
		case "destroyer":
			return destroyerAmount.get() > 0;
		case "submarine":
			return submarineAmount.get() > 0;
		case "cruiser":
			return cruiserAmount.get() > 0;
		case "battleship":
			return battleshipAmount.get() > 0;
		case "carrier":
			return carrierAmount.get() > 0;
		default:
			return false;
		}
	}
	/**
	 * check if the ship fits on the board
	 * @param idPos starting point of the ship, id of the stackpane
	 */
	private boolean hasSpace(String idPos) {
    	var idx = Integer.parseInt(String.valueOf(idPos.charAt(0)));
    	var idy = Integer.parseInt(String.valueOf(idPos.charAt(1)));
    	var bord = currentPlayer == 1 ? board1 : board2;
    	final int d = direction.get();
    	if(d == 1) {
    		if(idy + 1 - shipLength >= 0) {
    			for(int i = 0; i<shipLength; i++) {
    				if(bord[idx][idy - i] != 0) {
    					return false;
    				}
    			}
    			return true;
    		}
    	}
    	else if(d == 2) {
    		if(idx+shipLength <= boardSize) {
       			for(int i = 0; i<shipLength; i++) {
    				if(bord[idx + i][idy] != 0) {
    					return false;
    				}
    			}
    			return true;
    		}
    	}
    	else if(d == 3){
    		if(idy+shipLength <= boardSize) {
       			for(int i = 0; i<shipLength; i++) {
    				if(bord[idx][idy + i] != 0) {
    					return false;
    				}
    			}
        		return true;
    		}
    	}
    	else if(d == 4) {
    		if(idx+1-shipLength >= 0) {
       			for(int i = 0; i<shipLength; i++) {
    				if(bord[idx - i][idy] != 0) {
    					return false;
    				}
    			}
        		return true;
    		}
    	}
    	return false;
	}
	
	/**
	 * add handling for clicking on the enemy board
	 * @param pane
	 */
	private void addShootHandling(StackPane pane) {
		//make the pane clickable
		pane.setOnMouseClicked( e -> {
			if(canShoot) {
			var id = pane.getId();
			var idx = Integer.parseInt(String.valueOf(id.charAt(0)));
	    	var idy = Integer.parseInt(String.valueOf(id.charAt(1)));
	    	var list = boardsList.get(2-currentPlayer);
	    	int result = list[idx][idy];
	    	//if the target pane has a ship, mark the tile
	    	if(result > 0) {
	    		ImageView img = new ImageView(new Image(getClass().getResource("explosion.png").toExternalForm()));
				img.setFitHeight(paneHeight/ShipBoardData.getBoardSize());
				img.setFitWidth(paneWidth/ShipBoardData.getBoardSize());
				img.setPreserveRatio(true);
				Platform.runLater(() -> {
					((StackPane)gridPanes[4-currentPlayer].getChildren().get(idx+idy*boardSize)).getChildren().add(img);
					//add a backgroundimage in case normal imageview doesn't work
					Image waterImage  = new Image(getClass().getResource("BgBoom.png").toExternalForm());
					Background back = new Background(new BackgroundImage(waterImage,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize( 200, 200, true, true, true, false)));
					((StackPane)gridPanes[4-currentPlayer].getChildren().get(idx+idy*boardSize)).setBackground(back);
					((StackPane)gridPanes[2-currentPlayer].getChildren().get(idx+idy*boardSize)).getChildren().add(img);
				});
				//save the hit to control boards
	    		list[idx][idy] = -1;
	    		boardsList.set(2-currentPlayer, list);
	    		
	    		//check if the targeted ship sunk
	    		Ship shipp;
	    		if(currentPlayer == 1)
	    			shipp = ships1[result - 1];
	    		else shipp = ships2[result - 1];
	    		shipp.setLength(shipp.getLength()-1);
	    		
	    		//check if the player won the game
	    		playerHP[2-currentPlayer] -= 1;
	    		if(playerHP[2-currentPlayer] == 0) {
	    			winGame();
	    		}else if(shipp.getLength() == 0) {
	    			Platform.runLater(() -> {
	    				shipPlacementLabel.setText("Ship sunk! Shoot again");
	    			});
	    		}
	    		else {
	    			Platform.runLater(() -> {
	    				shipPlacementLabel.setText("Hit! Shoot again");
	    			});
	    		}
	    	} else if (result == 0) {
	    		//if the shot missed, mark the tile as a miss and swap turns
	    		ImageView img = new ImageView(new Image(getClass().getResource("splash.png").toExternalForm()));
				img.setFitHeight(paneHeight/boardSize);
				img.setFitWidth(paneWidth/boardSize);
				img.setPreserveRatio(true);
				Platform.runLater(() -> {
					((StackPane)gridPanes[4-currentPlayer].getChildren().get(idx+idy*boardSize)).getChildren().add(img);
					//add a backgroundimage in case normal imageview doesn't work
					Image waterImage  = new Image(getClass().getResource("BgSplash.png").toExternalForm());
					Background back = new Background(new BackgroundImage(waterImage,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,new BackgroundSize( 200, 200, true, true, true, false)));
					((StackPane)gridPanes[4-currentPlayer].getChildren().get(idx+idy*boardSize)).setBackground(back);
	    			((StackPane)gridPanes[2-currentPlayer].getChildren().get(idx+idy*boardSize)).getChildren().add(img);
				});
	    		list[idx][idy] = -1;
	    		boardsList.set(2-currentPlayer, list);
	    		Platform.runLater(() -> {
	    			shipPlacementLabel.setText("Missed! Press continue");
	    		});
	    		resetButton.disableProperty().set(false);
	    		canShoot = false;
	    	} else {
	    		//if the player has already shot this tile, don't skip a turn
	    		Platform.runLater(() -> {
	    			shipPlacementLabel.setText("You have already shot this square");
	    		});
	    	}
			}
		});
	}
	/**
	 * runs when a players hp reaches 0, makes resetbutton continue to win screen.
	 * creates and shows winscreen, if winscreen has been created, reinitializes it rather than creating a new one.
	 */
	public void winGame(){
		Platform.runLater(() -> {
			shipPlacementLabel.setText("You win!");
		});
		canShoot = false;
		resetButton.setOnAction( e -> {
			//Change behavior to changing turn
			ShipBoardData.getStages()[0].hide();
			
		});
		resetButton.disableProperty().unbind();
		resetButton.disableProperty().set(false);
		ShipBoardData.setWinnerName(currentPlayer == 1 ? pl1Name : pl2Name);
		try {
		//try to create winscreen, if winscreen has been created already, reinitialize it instead
		var resourceRoot = getClass();
		var form = "WinScreen.fxml";
		var loader = new FXMLLoader(resourceRoot.getResource(form));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		var stage = new Stage();
		stage.setTitle("LaivanUpotus");
		stage.setScene(scene);
		stage.show();
		ShipBoardData.addStage(stage, 2);
		}catch(IOException e) {
			System.out.println("Stage 2 already created, loading instead");
			ShipBoardData.getWinController().reInit();
			ShipBoardData.getStages()[2].show();
		}
	}
	
	/**
	 * add handling for drag and dropping ships to a stackpane on the board
	 * @param pane
	 */
	private void addDropHandling(StackPane pane) {
		//Highlight the area where the ship will be
		pane.setOnDragEntered(e -> {
	           Dragboard db = e.getDragboard();
	           if (db.hasContent(shipFormat) && draggedShip != null) {
	        	   String src = "AlphaOverlay.png";
	        	   //if ship can't be placed, make overlay red
	        	   boolean occupied = pane.getChildren().stream().anyMatch(t -> t instanceof ImageView);
	        	   boolean space = hasSpace(pane.getId());
	        	   if(!shipsLeft(shipType) || occupied || !space) {
	        		   src = "RedOverlay.png";
	        	   }
	        	   OverlayImage imag = new OverlayImage(new Image(getClass().getResource(src).toExternalForm()));
					imag.setFitHeight(paneHeight/boardSize);
					imag.setFitWidth(paneWidth/boardSize);
					pane.getChildren().add(imag);
	             }
		});
		pane.setOnDragExited(e -> {
			for(Object node : pane.getChildren()){
				if(node instanceof OverlayImage) {
					pane.getChildren().remove(node);
					break;
				}
			}
		});
		
		///Handle drag&drop
        pane.setOnDragOver(e -> {
           Dragboard db = e.getDragboard();
           if (db.hasContent(shipFormat) && draggedShip != null) {
                 e.acceptTransferModes(TransferMode.COPY);
             }
         });
        
         pane.setOnDragDropped(e -> {
            Dragboard db = e.getDragboard();
            int shipcanplace = 0;
            if (db.hasContent(shipFormat)) {
            	String id = pane.getId();
            	System.out.println(id);
            	var idx = Integer.parseInt(String.valueOf(id.charAt(0)));
            	var idy = Integer.parseInt(String.valueOf(id.charAt(1)));
            	Image shipPart1 = null;
            	Image shipPart2 = null;
            	Image shipPart3 = null;
            	Image shipPart4 = null;
            	Image shipPart5 = null;
            	Image[] shipParts = new Image[5];
            	boolean shipInReserve = shipsLeft(shipType);
            	//add images for shiptype for placement later and check if there are ships of the type remaining
            	String src;
            	String[] shipTypes = {"destroyer", "cruiser", "submarine", "battleship", "carrier"};
            	if(Arrays.asList(shipTypes).contains(shipType)) {
            		src = shipType;
            		src = src.substring(0, 1).toUpperCase() + src.substring(1);
            	}
            	else src = "";
            	for(int i = 0; i < shipLength; i++) {
            		System.out.println(src + "_" + (i + 1));
            		if(src!="")
            		shipParts[i] = new Image(getClass().getResource(src + "_" + (i + 1) + ".png").toExternalForm());
            		else shipParts[i] = new Image(getClass().getResource("").toExternalForm());
            	}
				shipPart1 = shipParts[0];
				shipPart2 = shipParts[1];
				shipPart3 = shipParts[2];
				shipPart4 = shipParts[3];
				shipPart5 = shipParts[4];
				
				//when there are ships of given type in reserve, check if ship can be placed in indicated position and direction
				if(shipInReserve) {
    			if(direction.get() == 1) {    				
    				if(idy+1-shipLength >= 0) {        					
    					shipcanplace = 1;
    					for(int j = 0;j<shipLength;j++) {
    					
    						switch(currentPlayer) {
    						case 1:
                					if(board1[idx][idy-j] == 1) {
                						shipcanplace = 0;
                					}
                					break;
	    					case 2:
	                				if(board2[idx][idy-j] == 1) {
	                					shipcanplace = 0;
	                				}
	                				break;
                					}
    					}
    				}


    			}
    			else if(direction.get() == 2) {
    				if(idx+shipLength <= boardSize) {
    					shipcanplace = 2;
    					for(int j = 0;j<shipLength;j++) {
        					
    						switch(currentPlayer) {
    						case 1:
                					if(board1[idx+j][idy] == 1) {
                						shipcanplace = 0;
                					}
                					break;
	    					case 2:
	                				if(board2[idx+j][idy] == 1) {
	                					shipcanplace = 0;
	                				}
	                				break;
                					}
    					}
    				}
    			}
    			else if(direction.get() == 3) {
    				if(idy+shipLength <= boardSize) {
    					shipcanplace = 3;
    					for(int j = 0;j<shipLength;j++) {
        					
    						switch(currentPlayer) {
    						case 1:
                					if(board1[idx][idy+j] == 1) {
                						shipcanplace = 0;
                					}
                					break;
	    					case 2:
	                				if(board2[idx][idy+j] == 1) {
	                					shipcanplace = 0;
	                				}
	                				break;
                					}
    					}
    				}
    			}
    			else if(direction.get() == 4) {
    				if(idx+1-shipLength >= 0) {
    					shipcanplace = 4;
    					for(int j = 0;j<shipLength;j++) {
        					
    						switch(currentPlayer) {
    						case 1:
                					if(board1[idx-j][idy] == 1) {
                						shipcanplace = 0;
                					}
                					break;
	    					case 2:
	                				if(board2[idx-j][idy] == 1) {
	                					shipcanplace = 0;
	                				}
	                				break;
                					}
    					}
    				}
    			}
    			}
				else {
					shipcanplace = 0;
				}
    			//on placing ship, remove 1 ship of type from reserve
    			if(shipcanplace != 0) {
    				if(shipType.equals("destroyer")){
    					destroyerAmount.set(destroyerAmount.get()-1);
    					}
    				else if(shipType.equals("cruiser")) {
    					cruiserAmount.set(cruiserAmount.get()-1);
    				}
    				else if (shipType.equals("submarine")) {
    					submarineAmount.set(submarineAmount.get()-1);
    					}
    				else if(shipType.equals("battleship")) {
    					battleshipAmount.set(battleshipAmount.get()-1);
    					}
    				else if(shipType.equals("carrier")) {
    					carrierAmount.set(carrierAmount.get()-1);
    				}
    				else {
    				}
    			}
    			//after checking if ship can be placed and removing ship, add ship to both board memory and visible grid
            	for(int i = 0;i<shipLength;i++) {
            		System.out.println(shipcanplace);
            		switch(shipcanplace) {
            		case 1:
    					switch(currentPlayer) {
						case 1:
							board1[idx][idy-i] = runningShipId;
							break;
						case 2:
							board2[idx][idy-i] = runningShipId;
							break;
						}
        						if(i == 0) {
        							ImageView imag = new ImageView(shipPart1);
        							imag.setRotate(-90);
        							imag.setFitHeight(paneHeight/boardSize);
        							imag.setFitWidth(paneWidth/boardSize);
        							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*(boardSize)))).getChildren().add(imag);
        						}
        						else if(i == 1) {
        							ImageView imag = new ImageView(shipPart2);
        							imag.setRotate(-90);
        							imag.setFitHeight(paneHeight/boardSize);
        							imag.setFitWidth(paneWidth/boardSize);
        							((StackPane) gridPanes[currentPlayer - 1].getChildren().get((idx+(idy*(boardSize)))-boardSize)).getChildren().add(imag);
        						}
        						else if(i == 2){
        							ImageView imag = new ImageView(shipPart3);
        							imag.setRotate(-90);
        							imag.setFitHeight(paneHeight/boardSize);
        							imag.setFitWidth(paneWidth/boardSize);
        							((StackPane) gridPanes[currentPlayer - 1].getChildren().get((idx+(idy*(boardSize)))-(2*boardSize))).getChildren().add(imag);
        						}
        						else if(i == 3){
        							ImageView imag = new ImageView(shipPart4);
        							imag.setRotate(-90);
        							imag.setFitHeight(paneHeight/boardSize);
        							imag.setFitWidth(paneWidth/boardSize);
        							((StackPane) gridPanes[currentPlayer - 1].getChildren().get((idx+(idy*(boardSize)))-(3*boardSize))).getChildren().add(imag);
        						}
        						else if(i == 4){
        							ImageView imag = new ImageView(shipPart5);
        							imag.setRotate(-90);
        							imag.setFitHeight(paneHeight/boardSize);
        							imag.setFitWidth(paneWidth/boardSize);
        							((StackPane) gridPanes[currentPlayer - 1].getChildren().get((idx+(idy*(boardSize)))-(4*boardSize))).getChildren().add(imag);
        						}
        				break;
            		case 2:
    					switch(currentPlayer) {
						case 1:
							board1[idx+i][idy] = runningShipId;
							break;
						case 2:
							board2[idx+i][idy] = runningShipId;
							break;
						}
    						if(i == 0) {
    							ImageView imag = new ImageView(shipPart1);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize))).getChildren().add(imag);
    						}
    						else if(i == 1) {
    							ImageView imag = new ImageView(shipPart2);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+1)).getChildren().add(imag);
    						}
    						else if(i == 2){
    							ImageView imag = new ImageView(shipPart3);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+2)).getChildren().add(imag);
    						}
    						else if(i == 3){
    							ImageView imag = new ImageView(shipPart4);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+3)).getChildren().add(imag);
    						}
    						else if(i == 4){
    							ImageView imag = new ImageView(shipPart5);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+4)).getChildren().add(imag);
    						}
    					break;
            		case 3:
        					switch(currentPlayer) {
        						case 1:
        							board1[idx][idy+i] = runningShipId;
        							break;
        						case 2:
        							board2[idx][idy+i] = runningShipId;
        							break;
        						}
    						if(i == 0) {
    							ImageView imag = new ImageView(shipPart1);
    							imag.setRotate(90);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize))).getChildren().add(imag);
    						}
    						else if(i == 1) {
    							ImageView imag = new ImageView(shipPart2);
    							imag.setRotate(90);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+boardSize*1)).getChildren().add(imag);
    						}
    						else if(i == 2){
    							ImageView imag = new ImageView(shipPart3);
    							imag.setRotate(90);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+boardSize*2)).getChildren().add(imag);
    						}
    						else if(i == 3){
    							ImageView imag = new ImageView(shipPart4);
    							imag.setRotate(90);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane)gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+boardSize*3)).getChildren().add(imag);
    						}
    						else if(i == 4){
    							ImageView imag = new ImageView(shipPart5);
    							imag.setRotate(90);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)+boardSize*4)).getChildren().add(imag);
    						}
    					break;
            		case 4:
        					switch(currentPlayer) {
        						case 1:
        							board1[idx-i][idy] = runningShipId;
        							break;
        						case 2:
        							board2[idx-i][idy] = runningShipId;
        							break;
        						}
    						if(i == 0) {
    							ImageView imag = new ImageView(shipPart1);
    							imag.setRotate(180);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize))).getChildren().add(imag);
    						}
    						else if(i == 1) {
    							ImageView imag = new ImageView(shipPart2);
    							imag.setRotate(180);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)-1)).getChildren().add(imag);
    						}
    						else if(i == 2){
    							ImageView imag = new ImageView(shipPart3);
    							imag.setRotate(180);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)-2)).getChildren().add(imag);
    						}
    						else if(i == 3){
    							ImageView imag = new ImageView(shipPart4);
    							imag.setRotate(180);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)-3)).getChildren().add(imag);
    						}
    						else if(i == 4){
    							ImageView imag = new ImageView(shipPart5);
    							imag.setRotate(180);
    							imag.setFitHeight(paneHeight/boardSize);
    							imag.setFitWidth(paneWidth/boardSize);
    							((StackPane) gridPanes[currentPlayer - 1].getChildren().get(idx+(idy*boardSize)-4)).getChildren().add(imag);
    						}
    					break;
        			default:
        				Platform.runLater(() -> {
        					shipPlacementLabel.setText("Cant place ship "+shipType+" on "+idx+", "+idy+", "+shipType+" available "+shipInReserve );
        				});
        				break;
        				}
        			

        		}
            	//if ship was placed, create a ship object for checking if ship has been sunk and add to a players ships
            	if(shipcanplace != 0) {
            		var s = new Ship(shipLength, runningShipId);
            		if(currentPlayer == 1)
            			ships1[runningShipId-1] = s;
            		else ships2[runningShipId-1] = s;
            		runningShipId++;
            		System.out.println("running id: " + runningShipId);
            	}
                e.setDropCompleted(true);
                draggedShip = null;
            		}
            });
	}
	
	
	
	/**
	 * removes all ships from board and empties board memory
	 */
	@FXML
	private void resetPlacement() {
		for(int i = 0; i<gridPanes[currentPlayer - 1].getChildren().size();i++) {
			((StackPane)gridPanes[currentPlayer - 1].getChildren().get(i)).getChildren().clear();
		}
		for(int i = 0; i<boardSize;i++) {
			for(int j = 0;j<boardSize;j++) {
				if(currentPlayer == 1) {
					board1[i][j] = 0;
				}
				if(currentPlayer == 2) {
					board2[i][j] = 0;
				}
			}
		}

		destroyerAmount.set(ShipBoardData.getDestroyerAmount());
		cruiserAmount.set(ShipBoardData.getCruiserAmount());
		submarineAmount.set(ShipBoardData.getSubmarineAmount());
		battleshipAmount.set(ShipBoardData.getBattleshipAmount());
		carrierAmount.set(ShipBoardData.getCarrierAmount());
		
		runningShipId = 1;
	}
	/**
	 * method that fires when startbutton is pressed, if player 1 setting ships, sets up board for player 2 ship setting
	 * if player 2 is setting ships, starts game and passes turn to player 1
	 * @throws IOException
	 */
	@FXML
	private void startGame() throws IOException{
		if(destroyerAmount.get()+cruiserAmount.get()+submarineAmount.get()+battleshipAmount.get()+carrierAmount.get() > 0) {
			Platform.runLater(() -> {
				shipPlacementLabel.setText("please place all remaining ships before moving on.");
			});
		}
		else if(currentPlayer == 1) {
			Platform.runLater(() -> {
				playerLabel.setText("Player 2: "+pl2Name+" setting ships" );
			});
			currentPlayer = 2;
			destroyerAmount.set(ShipBoardData.getDestroyerAmount());
			cruiserAmount.set(ShipBoardData.getCruiserAmount());
			submarineAmount.set(ShipBoardData.getSubmarineAmount());
			battleshipAmount.set(ShipBoardData.getBattleshipAmount());
			carrierAmount.set(ShipBoardData.getCarrierAmount());
			Platform.runLater(() -> {
				startButton.setText("Start Game");
			});
			((VBox)boardBox.getChildren().get(0)).getChildren().set(1, gridPanes[1]);
			runningShipId = 1;
		}
		else if(currentPlayer == 2) {
			
			resetButton.disableProperty().set(true);
			resetButton.textProperty().set("Continue");
			resetButton.setOnAction( e -> {
				//Change behavior to changing turn
				ShipBoardData.getStages()[0].hide();
				ShipBoardData.getStages()[1].show();
			});
			vboxR.getChildren().remove(shipBox);
			boardPane.getChildren().remove(directionImage);
			bottomBox.getChildren().remove(startButton);
			Platform.runLater(()->{playerLabel.setText("");});
			
			vboxR.getChildren().add(battleshipBoard3);
			
			
			var resourceRoot = getClass();
			var form = "Player1Call.fxml";
			var loader = new FXMLLoader(resourceRoot.getResource(form));
			Parent root = loader.load();
			Scene scene = new Scene(root);
			var stage = new Stage();
			stage.setTitle("LaivanUpotus");
			stage.setScene(scene);
			stage.show();
			ShipBoardData.addStage(stage, 1);
			ShipBoardData.getStages()[0].hide();
			ShipBoardData.setGameController(loader.getController());
		}
	}
	/**
	 * starts game turn for given player
	 * @param player player whose turn to start
	 * 
	 * sets abillity to shoot to true, sets gui elements to respective players setup
	 */
	public void startTurn(int player) {
		canShoot = true;
		resetButton.disableProperty().set(true);
		vboxL.getChildren().set(1, gridPanes[player - 1]);
		vboxR.getChildren().set(1, gridPanes[4-player]);
		currentPlayer = player;
		Platform.runLater(() -> {
			shipPlacementLabel.setText(playerNames[player-1] + "'s turn");
			labelL.setText(playerNames[player-1] + "'s board");
			labelR.setText(playerNames[player == 1 ? 1 : 0] + "'s board");
		});
		
		ShipBoardData.getGameController().changeTurn();
	}
	
	
	private boolean alreadyLoaded = false;
	private int paneWidth;
	private int paneHeight;
	private String shipType = "banana";
	private int boardSize;
	private String pl1Name;
	private String pl2Name;
	private int[][] board1;
	private int[][] board2;
	private SimpleIntegerProperty destroyerAmount = new SimpleIntegerProperty();
	private SimpleIntegerProperty cruiserAmount = new SimpleIntegerProperty();
	private SimpleIntegerProperty submarineAmount = new SimpleIntegerProperty();
	private SimpleIntegerProperty battleshipAmount = new SimpleIntegerProperty();
	private SimpleIntegerProperty carrierAmount = new SimpleIntegerProperty();
	
	private int currentPlayer = 1;
	private int shipLength = 10;
	private final DataFormat shipFormat = new DataFormat("MyShip");
	private static SimpleIntegerProperty direction = new SimpleIntegerProperty(1);
	
	public static void setDirection(int dir) {
		direction.set(dir);
	}
	public static SimpleIntegerProperty getDirection() {
		return direction;
	}
	

	private SimpleBooleanProperty canContinue;
	
	private ImageView draggedShip;
	
	GridPane[] gridPanes;
	
	@FXML
	private Label playerLabel;
	@FXML
	private Label destroyerAmoutLabel;
	@FXML
	private Label cruiserAmoutLabel;
	@FXML
	private Label submarineAmoutLabel;
	@FXML
	private Label battleshipAmoutLabel;
	@FXML
	private Label carrierAmoutLabel;
	@FXML
	private Label carrierTextLabel;
	@FXML
	private Label destroyerTextLabel;
	@FXML
	private Label cruiserTextLabel;
	@FXML
	private Label submarineTextLabel;
	@FXML
	private Label battleshipTextLabel;
	
	@FXML
	private Button resetButton;
	
	@FXML
	private Button startButton;
	@FXML
	private HBox bottomBox;
	
	@FXML
	private ImageView directionImage = new ImageView();
	@FXML
	private Label shipPlacementLabel;
	@FXML
	private BorderPane boardPane;
	
	//@FXML
	private GridPane battleshipBoard1;
	private GridPane battleshipBoard2;
	private GridPane battleshipBoard3;
	private GridPane battleshipBoard4;
	
	private ArrayList<int[][]> boardsList; 
	private int[] playerHP;
	private String[] playerNames;
	private boolean canShoot;
	
	@FXML
	private HBox boardBox;
	@FXML
	private Label separator;
	@FXML
	private VBox vboxL;
	@FXML
	private VBox vboxR;
	@FXML
	private Label labelL;
	@FXML
	private Label labelR;
	
	@FXML
	private VBox shipBox;
	
	@FXML
	private ImageView type1ShipView;
	@FXML
	private ImageView type2ShipView;
	@FXML
	private ImageView type3ShipView;
	@FXML
	private ImageView type4ShipView;
	@FXML
	private ImageView type5ShipView;
}
