package laivanupotus;

import java.io.IOException;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class WinController {

	
	public void initialize() throws IOException{
		ShipBoardData.setWinController(this);
		Platform.runLater(()->{
			winLabelw.setText(ShipBoardData.getWinnerName() + " wins!");
		}
		);
	}
	//reinitializes the UI when a new game starts
	public void reInit() {
		Platform.runLater(()->{
			winLabelw.setText(ShipBoardData.getWinnerName() + " wins!");
		}
		);
	}
	
	@FXML
	void closeGame() {
		Platform.exit();
	};
	@FXML
	void restart() {
		ShipBoardData.getShipBoardController().reinit();
		ShipBoardData.getStages()[0].hide();
		ShipBoardData.getStages()[2].hide();
		ShipBoardData.getStages()[3].show();
	}
	@FXML
	private Label winLabelw;
	@FXML
	private Button closeButton;
	@FXML
	private Button restartButton;
}

