package laivanupotus;

public class Ship {
	private int length;
	private int id;
	
	public Ship(int len, int i) {
		setLength(len);
		setId(i);
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
