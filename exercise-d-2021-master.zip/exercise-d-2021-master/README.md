# Harjoitus D - Exercise D

Alexander Auer(518980)
Lassi Kimppa (520850)

Teimme tehtävän eri osia vaihtelevasti, mutta työ jakautui tasaisesti molemmille.
