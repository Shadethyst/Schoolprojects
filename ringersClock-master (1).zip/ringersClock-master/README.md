# Hajautetut ohjelmistojärjestelmät ja pilvipalvelut 2020

# Distributed systems and cloud services 2020

## Harjoitustyö 2 tehtävänanto suomeksi

*[Tehtävänanto](https://gitlab.utu.fi/jarilehtogroup/ringersclock/-/blob/master/Tehtavananto.md)*

## Group work assignment 2 in  English

TBA

<!---
*[Assignment](https://gitlab.utu.fi/jarilehtogroup/ringersclock/-/blob/master/Assignment.md)*
-->
