# Distributed systems and cloud services 2020



## Group work 2 Ringer's clock

