package fi.utu.tech.ringersClock;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import fi.utu.tech.ringersClock.entities.WakeUpGroup;

public class ClientReader extends Thread{
	private ClockClient clock;
	private ObjectInputStream stream;
	private volatile boolean running = true;
	
	private AtomicBoolean dataRead = new AtomicBoolean(true);
	
	/**
	 * A class for reading incoming data
	 * @param cc ClockClient
	 * @param oIs InputStream
	 */
	public ClientReader(ClockClient cc, ObjectInputStream oIs) {
		clock = cc;
		stream = oIs;
	}
	/**
	 * Sets data to DataContainer
	 */
	public synchronized void setDataRead() {
		dataRead.set(true);
		notifyAll();
	}
	/**
	 * Wait for incoming data and pause until it has been read
	 */
	public synchronized void run()
	{
		System.out.println("ClientReader started");
		while(running) {
			while(!dataRead.get()) {
				try {
					System.out.println("waiting");
					wait();
					System.out.println("Data has been read, continuing reader");
				}catch(InterruptedException e) {
					System.out.println("InterruptedException");
				}
			}
			try {
				Object dat = stream.readObject();
				System.out.println("Data read " + dat);
				DataContainer.setData(dat);
				dataRead.set(false);
				System.out.println("Data has been saved, stopping reader");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}catch (SocketException e) {
				clock.setTerminate();
				e.printStackTrace();
				running = false;
			}catch (EOFException e) {
				clock.setTerminate();
				e.printStackTrace();
				running = false;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
