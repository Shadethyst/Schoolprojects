package fi.utu.tech.ringersClockServer;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.SocketException;
import java.util.ArrayList;

import fi.utu.tech.ringersClock.entities.WakeUpGroup;

public class ServerReader extends Thread{

	private ClockHandler handler;
	private WakeUpService wup;
	private ObjectInputStream oIs;
	private int groupId;
	private boolean isLeader;
	private ServerDataContainer sdc;
	private volatile boolean running = true;

	public ServerReader(ClockHandler ch, ObjectInputStream ois, int id, boolean leader, WakeUpService w, ServerDataContainer sdcc) {
		handler = ch;
		oIs = ois;
		groupId = id;
		isLeader = leader;
		wup = w;
		sdc = sdcc;
	}	
	/**
	 * reads data from clients stream, and commits actions based on data received.
	 */
	public void run() {
		while(running) {
			Object dat;
			try {
				dat = oIs.readObject();
				isLeader = handler.isOnkoJohtaja();
				if(dat instanceof String) {
					var str = (String)dat;
					switch(str) {
					case("resign"):
						System.out.println("Resign signal received");
					case("cancel"):
						if(isLeader){
							System.out.println("ryhmänjohtaja resigned");
							sdc.addGroupToRemove(groupId);
						}else {
							System.out.println("mentiin elseen");
							sdc.getGroup(groupId).addMember(-1);
							handler.setGroupId(-1);
						}
						break;
					case("alarm"):
						System.out.println("Alarm received");
						sdc.acceptAlarm(groupId);
						break;
					}
				}else if(dat instanceof Object[]) {
					var str = (String)((Object[])dat)[0];
					var groop = (WakeUpGroup)((Object[])dat)[1];
					if(str.equals("join")) {
						if(groop.getID() != handler.getGroupId()) {
							if(groupId != -1) {
							if(groupId != groop.getID()) {
								sdc.getGroup(groupId).addMember(-1);
							}
							}
							if(handler.isOnkoJohtaja())
							{
								sdc.addGroupToRemove(handler.getGroupId());
								handler.setOnkoJohtaja(false);
							}
							handler.setGroupId(groop.getID());
							System.out.println("Set groupId to: " + handler.getGroupId());
							groupId = groop.getID();
							System.out.println(groupId);
							sdc.setMemberToGroup(sdc.getGroup(groupId), 1); //Nullpointer
							handler.setAlreadyJoinedGroup(true);
						}
					}
					if(str.equals("create")) {
						if(handler.isOnkoJohtaja())
							sdc.addGroupToRemove(handler.getGroupId());
						handler.setAlreadyWokeUp(false);
						handler.setOnkoJohtaja(true);
						int runn = sdc.getRunningGroupId();
						sdc.increaseRunningGroupId();
						handler.setGroupId(runn);
						groupId = runn;
						groop.setID(runn);
						sdc.addWug(groop);
						handler.setAlreadyJoinedGroup(true);

						System.out.println("#######Received new group####### johtaja?: "+handler.isOnkoJohtaja() + " runn: " + runn);
					}
				}
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}catch (SocketException e) {
				handler.setTerminate();
				e.printStackTrace();
				running = false;
			}catch (EOFException e) {
				handler.setTerminate();
				e.printStackTrace();
				running = false;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
