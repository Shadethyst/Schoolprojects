package fi.utu.tech.ringersClock;

/**
 * A class that holds data from ClientReader
 */
public class DataContainer {
	private static Object data = null;

	public static synchronized Object getData() {
		return data;
	}
	public static  synchronized void setData(Object data) {
		System.out.println("Data has been set to " + data);
		DataContainer.data = data;
	}
}
