package fi.utu.tech.ringersClockServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import fi.utu.tech.ringersClock.entities.WakeUpGroup;
/**
 * contains shared data for connection handlers and wakeupservice.
 *
 * @author lassi
 *
 */
public class ServerDataContainer {

	private List<WakeUpGroup> groups;
	private boolean wugHasData = false;
	private ClockHandler cHandler = null;
	private boolean writeableCHandler = true;
	private boolean cHandlerHasData = false;
	private int versionId = 0;
	private List<WakeUpGroup>groupsToRemove;
	private boolean readGroupsToRemove = true;
	private int runningGroupId = 0;
	
	public ServerDataContainer() {
		super();
		groups = Collections.synchronizedList(new ArrayList<WakeUpGroup>());
		groupsToRemove = Collections.synchronizedList(new ArrayList<WakeUpGroup>());
	}
/**
 * sets group with id i to be removed at next wakeupservice loop
 * @param i
 */
	public synchronized void addGroupToRemove(int i) {
		for(WakeUpGroup g: groups) {
			if(g.getID() == i) {
				System.out.println("added a group to remove");
				groupsToRemove.add(g);
			}
		}
	}
	/**
	 * removes a group from list of groups to remove once it has been removed
	 * @param i
	 */
	public synchronized void removeGroupRemove(int i) {
		for(WakeUpGroup g: groups) {
			if(g.getID() == i) {
				groupsToRemove.remove(g);
				versionId++;
				break;
			}
		}
	}
	/**
	 * checks which groups still need removing and lets next group in queue be removed
	 * @return
	 */
	public synchronized List<WakeUpGroup> getGroupToRemove() {
		return groupsToRemove;
	}
	/**
	 * adds specified amount of members to wakeupgroup.
	 * @param g
	 * @param add
	 */
	public void setMemberToGroup(WakeUpGroup g, int add) {
		g.addMember(add);
		for(int i = 0; i<groups.size();i++) {
			if(groups.get(i).getID() == g.getID()) {
				groups.set(i, g);
			}
		}
	}
	/**
	 * sets specified amount of members to be woken up, also used to remove members from being woken up once a handler has woken its member.
	 * @param g
	 * @param add
	 */
	public void setMemberToWakeUp(WakeUpGroup g, int add) {
		g.addMembersToWakeUp(add);
		System.out.println("Member set to wakeup: " + g.getMembersToWakeUp());
		if(g.getMembersToWakeUp() == 0)
			g.setHeratetty(true);
	}
	/**
	 * sets group with id specified by i to be woken up after leader accepts
	 * @param i
	 */
	public void acceptAlarm(int i) {
		System.out.println("Alarm accepted for id: " + i);
		
		synchronized(groups) {
			groups.forEach(g -> {
				if(g.getID() == i) {
					g.addMembersToWakeUp(g.getMembers());
					System.out.println("Group found with same id, members in the group: " + g.getMembers());
				}
			});
		}
	}
	/**
	 * adds a wakeupgroup to synchronized list.
	 * @param wugg
	 */
	public synchronized void addWug(WakeUpGroup wugg) {
		System.out.println("Entered addWug with group " + wugg.getName());
		groups.add(wugg);
		versionId++;
	}
	/**
	 * removes a wakeupgroup from synchronized list
	 * @param i
	 */
	public synchronized void removeWug(int i) {
		System.out.println("Deleting wug");
		for(WakeUpGroup wgg : groups) {
			if(wgg.getID() == i) {
				groups.remove(wgg);
				break;
			}
		}
		versionId++;
	}
	/**
	 * adds a clockhandler to be read by wakeupservice for later use
	 * @param ch
	 */
	public synchronized void setCHandler(ClockHandler ch) {
		while(!writeableCHandler){
			try { 
				wait();
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Saving client");
		writeableCHandler = false;
		cHandler = ch;
		cHandlerHasData = true;
		notifyAll();
	}
	/**
	 * returns clockhandler, used in wakeupservice to save clockhandlers in arraylist
	 * @return
	 */
	public synchronized ClockHandler getCHandler() {
		System.out.println("Getting client");
		writeableCHandler = true;
		cHandlerHasData = false;
		notifyAll();
		return cHandler;
	}
	/**
	 * returns synchronized wakeupgroup list, used in wakeupservice
	 * @return
	 */
	public synchronized List<WakeUpGroup> getGroups() {
		return groups;
	}
	/**
	 * returns specified wakeupgroup from list
	 * @param i
	 * @return
	 */
	public synchronized WakeUpGroup getGroup(int i) {
		for(WakeUpGroup gr : groups) {
			if(gr.getID() == i) {
				return gr;
			}
		}
		return null;
	}
	public synchronized void setGroups(List<WakeUpGroup> groups) {
		this.groups = groups;
	}
	public synchronized boolean isWugHasData() {
		return wugHasData;
	}
	public synchronized boolean iscHandlerHasData() {
		return cHandlerHasData;
	}
	public synchronized int getVersionId() {
		return versionId;
	}
	public synchronized void increaseVersionId() {
		versionId++;
	}
	public synchronized int getRunningGroupId() {
		return runningGroupId;
	}
	public synchronized void increaseRunningGroupId() {
		runningGroupId++;
	}
}
