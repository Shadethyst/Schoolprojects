package fi.utu.tech.weatherInfo;

import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import java.net.*;
import java.util.ArrayList;

public class FMIWeatherService {

	private final String CapURL = "https://opendata.fmi.fi/wfs?request=GetCapabilities";
	private final String FeaURL = "https://opendata.fmi.fi/wfs?request=GetFeature";
	private final String ValURL = "https://opendata.fmi.fi/wfs?request=GetPropertyValue";
	private static final String DataURL = "http://opendata.fmi.fi/wfs?service=WFS&version=2.0.0&request=getFeature&storedquery_id=fmi::forecast::hirlam::surface::point::multipointcoverage&place=turku&";

	/*
	 * In this method your are required to fetch weather data from The Finnish
	 * Meteorological Institute. The data is received in XML-format.
	 */

	/**
	 * Fetches weather data and returns it
	 * @return
	 */
	public static WeatherData getWeather() {
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		Document doc=null;
		
		try {
			db = dbf.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}

		try {
		doc = db.parse(new URL(DataURL).openStream());
		}catch(Exception e) {
			e.printStackTrace();
		}

		String data = "";
		NodeList nList = null;
		try {
			nList = doc.getElementsByTagName("gml:doubleOrNilReasonTupleList");
			data = nList.item(0).getTextContent();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String[] datas = data.split(" ");
		ArrayList<Float> values = new ArrayList<Float>();
		for(String d:datas) {
			if(!d.isBlank()) {
			values.add(Float.parseFloat(d));
			}
		}
		float temp = values.get(1);
		float rain = values.get(16);
		
		WeatherData weatherData = new WeatherData(rain!=0.0, temp>0.0);

		return weatherData;
	}

}
