package fi.utu.tech.ringersClockServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import fi.utu.tech.ringersClock.entities.WakeUpGroup;

public class ClockHandler extends Thread{
	private Socket client;
	private int groupId = -1;
	private boolean onkoJohtaja = false;
	private WakeUpService wup;
	InputStream iS = null;
	OutputStream oS = null;
	ObjectInputStream oIs = null;
	ObjectOutputStream oOs = null;
	private ServerReader reader;
	private ServerDataContainer sdc;
	private boolean updateGroups = false;
	private boolean alreadyWokeUp = false;
	private boolean terminate = false;
	private volatile boolean running = true; 
	private AtomicBoolean readyToWakeUp;
	private boolean groupDeleted = false;
	private int versionId = 0;
	private boolean alreadyJoinedGroup = false;
	
	public ClockHandler(Socket s, WakeUpService w, ServerDataContainer sdcc) {
		client = s;
		wup = w;
		sdc = sdcc;
		try {
		iS = client.getInputStream();
		oS = client.getOutputStream();
		oIs = new ObjectInputStream(iS);
		oOs = new ObjectOutputStream(oS);
		readyToWakeUp = new AtomicBoolean(false);
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	public void run() {
		System.out.println("ClockHandler started");
		reader = new ServerReader(this, oIs, groupId, onkoJohtaja, wup, sdc);
		reader.start();
		while(running) {		
			int i = sdc.getVersionId();
			if(versionId != i) {
				ArrayList<WakeUpGroup> gg = new ArrayList<WakeUpGroup>();
				synchronized(sdc.getGroups()) {
					sdc.getGroups().forEach((group)->{
						gg.add(group);
					});
				};
				paivitaLista(gg);
				versionId = i;
			}
			if(sdc.getGroup(groupId) == null && alreadyJoinedGroup) {
				groupDeleted = true;
				alreadyJoinedGroup = false;
			}
			if(groupDeleted && !onkoJohtaja) {
				poistaRyhmasta();
			}
			if(groupId != -1) {
				if(sdc.getGroup(groupId) != null) {
					if(!alreadyWokeUp && sdc.getGroup(groupId).getMembersToWakeUp() != 0) {
						alreadyWokeUp = true;
						heratus();
					}
				}
			}
			
			//reader.setDataRead();
			
			if(terminate) {
				Close();
			}
			if(readyToWakeUp.get()) {
				johtajaHeratus(groupId);
				readyToWakeUp.set(false);
			}
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	//Close connection and client thread
	public void Close() {
		running = false;
		try {
		iS.close();
		oS.close();
		client.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void poistaRyhmasta() {
		try {
			oOs.writeObject("poistettu ryhmasta");
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		groupId = -1;
		onkoJohtaja = false;
		groupDeleted = false;
		alreadyJoinedGroup = false;
	}
	//Called by WakeUpService
	public void heratus() {
		try {
			oOs.writeObject("wake up");
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		var g = sdc.getGroup(groupId);
		sdc.setMemberToWakeUp(g, -1);
		onkoJohtaja = false;
		groupId = -1;
	}
	public void heratusJohtaja() {
		readyToWakeUp.set(true);
	}
	public void johtajaHeratus(int id) {
		try {
			oOs.writeObject(id);
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void paivitaLista(ArrayList<WakeUpGroup> groops) {
		try {
			var b = new WakeUpGroup[groops.size()];
			for(int i = 0; i < groops.size() ; i++) {
				b[i] = groops.get(i);
			}
			oOs.writeObject(b);
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("list updated");
	}
	//Getters and setters
	public boolean isOnkoJohtaja() {
		return onkoJohtaja;
	}
	public void setOnkoJohtaja(boolean onkoJohtaja) {
		this.onkoJohtaja = onkoJohtaja;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public WakeUpService getWup() {
		return wup;
	}
	public void setUpdateGroups(boolean updateGroups) {
		this.updateGroups = updateGroups;
	}
	public boolean getUpdateGroups() {
		return updateGroups;
	}
	public void setAlreadyWokeUp(boolean b) {
		alreadyWokeUp = b;
	}
	public void setTerminate() {
		terminate = true;
	}
	public void setGroupDeleted(boolean b) {
		groupDeleted = b;
	}
	public void setAlreadyJoinedGroup(boolean b) {
		alreadyJoinedGroup = b;
	}
}
