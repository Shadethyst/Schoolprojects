package fi.utu.tech.ringersClockServer;

import fi.utu.tech.weatherInfo.FMIWeatherService;
import fi.utu.tech.weatherInfo.WeatherData;

public class ServerApp {

	private static ServerApp app;
	private ServerSocketListener listener;
	private WakeUpService wup;
	private String serverIP = "127.0.0.1";
	private int serverPort = 3000;
	private ServerDataContainer sdc;
/**
 * starts server application, creates a listener for incoming connections, a container for multithread data,
 * and starts service for waking up clients.
 */
	public ServerApp() {
		sdc = new ServerDataContainer();
		wup = new WakeUpService(sdc);
		listener = new ServerSocketListener(serverIP, serverPort, wup, sdc);
		wup.start();
		listener.start();
	}

	public static void main(String[] args) {
		
		System.out.println("Starting server...");
		app = new ServerApp();
	}

}
