package fi.utu.tech.ringersClock;

import java.io.IOException;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

import fi.utu.tech.ringersClock.entities.WakeUpGroup;

/*
 * A class for handling network related stuff
 */

public class ClockClient extends Thread {

	private String host;
	private int port;
	private Gui_IO gio;
	private ClientReader reader;
	private boolean running = true;
	private boolean terminate = false;
	private boolean canCreate = true;
	private ArrayList<WakeUpGroup> groops = new ArrayList<WakeUpGroup>();
	
	ObjectInputStream oIs = null;
	ObjectOutputStream oOs = null;
	InputStream iS = null;
	OutputStream oS = null;
	Socket sock = null;

	/**
	 * A class to handle client interactions
	 * @param host
	 * @param port
	 * @param gio
	 */
	public ClockClient(String host, int port, Gui_IO gio) {
		this.host = host;
		this.port = port;
		this.gio = gio;
		gio.setCClient(this);
	}
	/**
	 * Handle incoming data and send data to server
	 */
	public void run() {
		System.out.println("Host name: " + host + " Port: " + port + " Gui_IO:" + gio.toString());
		
		try {
			sock = new Socket(host,port);
			iS = sock.getInputStream();
			oS = sock.getOutputStream();
			oOs = new ObjectOutputStream(oS);
			oIs = new ObjectInputStream(iS);
			reader = new ClientReader(this, oIs);
			reader.start();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		while(running) {
			if(DataContainer.getData() != null) {
				System.out.println("Reading data");
				var dat = DataContainer.getData();

				System.out.println("Trying int...");
				if(dat instanceof Integer) {
					System.out.println("Integer read: " + (int)dat);
					System.out.println("groops: " + groops);
					WakeUpGroup g = null;
					for(WakeUpGroup wg : groops) {
						System.out.println("wg id is: " + wg.getID());
						if(wg.getID() == (int)dat) {
							g = wg;
							break;
						}
					}
					if(g != null)
						gio.confirmAlarm(g);
				}
				if(dat instanceof String) {
					var str = (String)dat;
					switch(str){
						case("wake up"):
							gio.alarm();
							canCreate = true;
							break;
						case("poistettu ryhmasta"):
							System.out.println("poistettu ryhmasta");
							gio.clearAlarmTime();
							break;
					}
				}
				if(dat instanceof WakeUpGroup[]) {
					var aray = (WakeUpGroup[])dat;
					System.out.println("WakeUpGroup[] read, size: "+aray.length);
					var alist = new ArrayList<WakeUpGroup>();
					for(WakeUpGroup wug : aray) {
						alist.add(wug);
					}
					groops = alist;
					gio.fillGroups(alist);
					
				}
				
				DataContainer.setData(null);
			}
			reader.setDataRead();
			if(terminate) {
				close();
			}
		}
	}
	/**
	 * Closes the connection
	 */
	private void close() {
		gio.appendToStatus("Server connection failed. Please restart the client.");
		try {
		iS.close();
		oS.close();
		sock.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		running = false;
	}
	//These are called from GUI_IO
	public void alarmAccepted(){
		try {
			oOs.writeObject("alarm");
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void alarmCanceled() {
		try {
			oOs.writeObject("cancel");
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Create a group and send it to server
	 * @param groop Group to send
	 */
	public void createGroup(WakeUpGroup groop) {
		canCreate = false;
		try {
			System.out.println("Sending newly created group");
			var oa = new Object[2];
			oa[0] = "create";
			oa[1] = groop;
			oOs.writeObject(oa);
			oOs.flush();
			System.out.println("Group sent");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Join a group
	 * @param groop
	 */
	public void joinGroup(WakeUpGroup groop) {
		canCreate = true;
		try {
			var oa = new Object[2];
			oa[0] = "join";
			oa[1] = groop;
			oOs.writeObject(oa);
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Resign from current group
	 */
	public void resignGroup() {
		canCreate = true;
		try {
			oOs.writeObject("resign");
			oOs.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Sets the client to terminate
	 */
	public void setTerminate() {
		terminate = true;
	}
	/**
	 * Can current client create more groups?
	 * @return
	 */
	public boolean isCanCreate() {
		return canCreate;
	}
}
