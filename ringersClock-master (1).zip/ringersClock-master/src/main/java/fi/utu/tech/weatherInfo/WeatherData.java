package fi.utu.tech.weatherInfo;

/*
 * Class presenting current weather
 * Is returned by  weather service class
 */

public class WeatherData {

	/*
	 * What kind of data is needed? What are the variable types. Define class
	 * variables to hold the data
	 */
	
	private boolean Sataako;
	private boolean Lampotila;

	/*
	 * Since this class is only a container for weather data we only need to set the
	 * data in the constructor.
	 */

	public WeatherData(boolean sade, boolean lampo) {
		this.Sataako = sade;
		this. Lampotila = lampo;
	}
	public boolean getSataako()
	{ 
		return Sataako;
	}
	public boolean getLampotila()
	{
		return Lampotila;
	}

}
