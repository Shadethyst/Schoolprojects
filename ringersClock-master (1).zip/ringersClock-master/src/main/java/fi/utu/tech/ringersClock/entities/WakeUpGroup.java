package fi.utu.tech.ringersClock.entities;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * Entity class presenting a WakeUpGroup. The class is not complete.
 * You need to add some variables.
 */

public class WakeUpGroup implements Serializable {

	private static int currentID = 0;
	private static final long serialVersionUID = 1L;
	private String name;
	private Integer ID;
	private int hours;
	private int minutes;
	private boolean noRain;
	private boolean temp;
	private int members = 1;
	private AtomicInteger membersToWakeUp;
	private boolean heratetty = false;
	private boolean johtajaheratetty = false;

	public WakeUpGroup(String name, int tunnit, int minuutit, boolean eiSadetta, boolean lampotila) {
		super();
		membersToWakeUp = new AtomicInteger(0);
		this.ID = currentID;
		currentID++;
		this.name = name;
		this.hours = tunnit;
		this.minutes = minuutit;
		this.noRain = eiSadetta;
		this.temp = lampotila;
	}

	public String getName() {
		return this.name;
	}

	public Integer getID() {
		return this.ID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setID(Integer ID) {
		this.ID = ID; 
	}

	@Override
	public String toString() {
		return this.getName();
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public int getMinutes() {
		return minutes;
	}

	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	public boolean isNoRain() {
		return noRain;
	}

	public void setNoRain(boolean noRain) {
		this.noRain = noRain;
	}

	public boolean isTemp() {
		return temp;
	}

	public void setTemp(boolean temp) {
		this.temp = temp;
	}

	public int getMembers() {
		return members;
	}

	public void addMember(int i) {
		members = members + i;
	}

	public int getMembersToWakeUp() {
		return membersToWakeUp.get();
	}

	public void addMembersToWakeUp(int m) {
		membersToWakeUp.set(membersToWakeUp.get() + m);
	}

	public boolean isHeratetty() {
		return heratetty;
	}

	public void setHeratetty(boolean heratetty) {
		this.heratetty = heratetty;
	}

	public boolean isJohtajaheratetty() {
		return johtajaheratetty;
	}

	public void setJohtajaheratetty(boolean johtajaheratetty) {
		this.johtajaheratetty = johtajaheratetty;
	}

}
