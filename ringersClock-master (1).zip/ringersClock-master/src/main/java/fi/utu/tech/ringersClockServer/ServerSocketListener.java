package fi.utu.tech.ringersClockServer;

import java.net.ServerSocket;
import java.net.Socket;

public class ServerSocketListener extends Thread {

	private String host;
	private int port;
	private WakeUpService wup;
	private ServerDataContainer sdc;

	/**
	 * Listen to new connections
	 * @param host
	 * @param port
	 * @param wup
	 * @param sdcc
	 */
	public ServerSocketListener(String host, int port, WakeUpService wup, ServerDataContainer sdcc) {
		this.host = host;
		this.port = port;
		this.wup = wup;
		sdc = sdcc;
	}
	/**
	 * Save new client connections in ServerDataContainer
	 */
	public void run(){
		try{
		ServerSocket sc = new ServerSocket(port);
		while(true) {
			System.out.println("Running socketlistener loop");
			Socket clientSocket = sc.accept();
			System.out.println("Socket accepted");
			ClockHandler handler = new ClockHandler(clientSocket, wup, sdc);
			handler.start();
			sdc.setCHandler(handler);
			}
		}
		catch(Exception e) {
			}
	}
}
