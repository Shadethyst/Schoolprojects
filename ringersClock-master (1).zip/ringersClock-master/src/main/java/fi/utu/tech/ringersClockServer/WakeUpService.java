package fi.utu.tech.ringersClockServer;

import java.util.*;
import java.time.*;

import fi.utu.tech.ringersClock.entities.WakeUpGroup;
import fi.utu.tech.weatherInfo.*;

public class WakeUpService extends Thread {
	private ArrayList<ClockHandler> clients = new ArrayList<ClockHandler>();
	private ServerDataContainer sdc;
	
	/**
	 * Wakeupservice handles all clients on the serverside and decides when to wake up
	 * @param sdcc data container
	 */
	public WakeUpService(ServerDataContainer sdcc) {
		sdc = sdcc;
	}
	/**
	 * Check if time is right for wake up and if there are new clients
	 */
	public void run() {
		while(true) {
			var time = LocalDateTime.now();
			var min = time.getMinute();
			var hour = time.getHour();
			var groups = sdc.getGroups();
			synchronized(groups) {groups.forEach((group)->{
				if(group.getMinutes() == min && group.getHours() == hour && !group.isJohtajaheratetty()) {
					heratus(group);
					group.setJohtajaheratetty(true);
				}
				if(group.isHeratetty() && group.getMembersToWakeUp() == 0) {
					sdc.addGroupToRemove(group.getID());
				}
			});

			}
			if(sdc.iscHandlerHasData()) {
				lisaaClient(sdc.getCHandler());
			}
			ryhmanpoistaja();
			for(ClockHandler ch : clients) {
				if(!ch.isAlive()) {
					if(ch.isOnkoJohtaja() && ch.getGroupId() != -1) {
						sdc.addGroupToRemove(ch.getGroupId());
					}
					clients.remove(ch);
					break;
				}
			}
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * Removes members from groups and groups from the list when needed
	 */
	public void ryhmanpoistaja() {
		for(WakeUpGroup g : sdc.getGroups()) {
			boolean found = false;
			for(WakeUpGroup j : sdc.getGroupToRemove()) {
				if(g.getID() == j.getID()) {
					for(ClockHandler cl : clients) {
						if(g.getID() == cl.getGroupId()) {
							poistaRyhmasta(cl);
						}
					}
					System.out.println("found group to remove");
					sdc.removeWug(g.getID());
					sdc.removeGroupRemove(g.getID());
					found = true;
					break;
				}
			}
			if(found) {
				break;
			}
		}
	}
	public void poistaRyhmasta(ClockHandler cl) {
		cl.setGroupId(-1);
		cl.setOnkoJohtaja(false);
		cl.setGroupDeleted(true);
	}
	public void lisaaClient(ClockHandler h){
		clients.add(h);
	}
	/**
	 * Checks if current weather conditions are ok
	 * @param wug the group that you want to check for
	 * @param wd weatherdata from the internet
	 * @return
	 */
	public boolean vertaaVaatimus(WakeUpGroup wug, WeatherData wd) {
		return (!wug.isNoRain() || !wd.getSataako()) && (!wug.isTemp() || wd.getLampotila());
	}
	/**
	 * Asks the leader if they want to wake up the group
	 * @param wug group to wake up
	 */
	public void heratus(WakeUpGroup wug) {
		for(ClockHandler ch : clients) {
			if(ch.getGroupId() == wug.getID() && ch.isOnkoJohtaja()) {
				WeatherData dat = FMIWeatherService.getWeather();
				if(vertaaVaatimus(wug, dat)) {
					ch.heratusJohtaja();
				}
			}
		}
	}
}
